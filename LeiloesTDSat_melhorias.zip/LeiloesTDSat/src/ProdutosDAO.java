/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Adm
 */

import java.sql.PreparedStatement;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class ProdutosDAO {
    
    Connection conn;
    PreparedStatement prep;
    ResultSet resultset;
    ArrayList<ProdutosDTO> listagem = new ArrayList<>();
    
    public boolean cadastrarProduto (ProdutosDTO produto){
        
        conn = new conectaDAO().connectDB();
        String sql = "INSERT INTO `produtos` (`nome`, `valor`, `status`) VALUES (?, ?, ?)";
        try {
            String valor = Integer.toString(produto.getValor());
        
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, produto.getNome());
            ps.setString(2, valor);
            ps.setString(3, produto.getStatus());

            int linhas = ps.executeUpdate();
            ps.close();
            System.out.println("Produto cadastrado com sucesso!");
            return linhas > 0;

        } catch (SQLException ex) {
            System.out.println("Erro ao inserir produto: " + ex.getMessage());
            return false;
        } finally {
            fecharConexao();
        }
    }
        
    
    
    public ArrayList<ProdutosDTO> listarProdutos(){
        
        ArrayList<ProdutosDTO> lista = new ArrayList<>();
        conn = new conectaDAO().connectDB();
        String sql = "SELECT id, nome, valor, status FROM produtos";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(montarProduto(rs));
            }
            rs.close();
            ps.close();

        } catch (SQLException ex) {
            System.out.println("Erro ao listar produtos: " + ex.getMessage());
        } finally {
            fecharConexao();
        }
        return lista;
    }
    
    
    /**
     * Atualiza o status do produto informado para "Vendido".
     */
    public boolean venderProduto(int id){
        
        conn = new conectaDAO().connectDB();
        String sql = "UPDATE produtos SET status = ? WHERE id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "Vendido");
            ps.setInt(2, id);

            int linhas = ps.executeUpdate();
            ps.close();
            System.out.println("Produto vendido com sucesso!");
            return linhas > 0;

        } catch (SQLException ex) {
            System.out.println("Erro ao vender produto: " + ex.getMessage());
            return false;
        } finally {
            fecharConexao();
        }
    }
    
    
    /**
     * Busca todos os produtos com status "Vendido".
     */
    public ArrayList<ProdutosDTO> listarProdutosVendidos(){
        
        ArrayList<ProdutosDTO> lista = new ArrayList<>();
        conn = new conectaDAO().connectDB();
        String sql = "SELECT id, nome, valor, status FROM produtos WHERE status = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "Vendido");

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(montarProduto(rs));
            }
            rs.close();
            ps.close();

        } catch (SQLException ex) {
            System.out.println("Erro ao listar produtos vendidos: " + ex.getMessage());
        } finally {
            fecharConexao();
        }
        return lista;
    }
    
    
    private ProdutosDTO montarProduto(ResultSet rs) throws SQLException {
        ProdutosDTO produto = new ProdutosDTO();
        produto.setId(rs.getInt("id"));
        produto.setNome(rs.getString("nome"));
        produto.setValor(rs.getInt("valor"));
        produto.setStatus(rs.getString("status"));
        return produto;
    }
    
    
    private void fecharConexao() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao fechar conexão: " + ex.getMessage());
        }
    }
        
    
}

